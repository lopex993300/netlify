export default [
  {
    id: 1,
    value: '0989876823',
    label: '0989876823',
  },
  {
    id: 2,
    value: '2341231213',
    label: '2341231213',
  },
];
