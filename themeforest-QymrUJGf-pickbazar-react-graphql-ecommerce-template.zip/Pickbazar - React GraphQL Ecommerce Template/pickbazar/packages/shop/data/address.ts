export default [
  {
    id: 1,
    value: 'mohakhali-dohs-dhaka',
    label: '1st Floor, House 149, Road-22, Mohakhali DOHS, Dhaka - North',
  },
  {
    id: 2,
    value: 'mohakhali-dohs-dhaka2',
    label: '1st Floor, House 149, Road-22, Mohakhali DOHS, Dhaka - North',
  },
];
